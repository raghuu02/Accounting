(function () {
  var btn = document.querySelector('.menu-btn');
  var nav = document.getElementById('site-nav');
  if (btn && nav) {
    btn.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      btn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    });
  }

  // Mark the current page in the menu
  var page = (location.pathname.split('/').pop() || 'index.html').replace('.html', '') || 'index';
  document.querySelectorAll('[data-page]').forEach(function (a) {
    if (a.getAttribute('data-page') === page) a.classList.add('active');
  });

  // Hours and services picker: builds an email with the choices
  var hire = document.getElementById('hireBtn');
  if (hire) {
    var update = function () {
      var h = [].map.call(document.querySelectorAll('[data-group="hours"] .opt.on'), function (b) { return b.getAttribute('data-v'); });
      var v = [].map.call(document.querySelectorAll('[data-group="services"] .opt.on'), function (b) { return b.getAttribute('data-v'); });
      var body = 'Hours needed: ' + (h.join(', ') || 'not selected') + '\nServices needed: ' + (v.join(', ') || 'not selected');
      hire.setAttribute('href', 'mailto:accounting@upgraft.com?subject=' + encodeURIComponent('Hire in 24 Hours') + '&body=' + encodeURIComponent(body));
    };
    document.querySelectorAll('.opts').forEach(function (g) {
      g.addEventListener('click', function (e) {
        var b = e.target.closest('.opt');
        if (!b) return;
        if (g.getAttribute('data-group') === 'hours') {
          g.querySelectorAll('.opt').forEach(function (x) { x.classList.remove('on'); });
        }
        b.classList.toggle('on');
        b.setAttribute('aria-pressed', b.classList.contains('on') ? 'true' : 'false');
        update();
      });
    });
    update();
  }
})();
